package com.neosoft.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//repository that extends CrudRepository
import org.springframework.data.repository.query.Param;

import com.neosoft.model.User;
public interface UserRepository extends JpaRepository<User, Integer>
{
	public List<User> findByUserFirstNameOrSurNameOrPinCode(@Param("userFirstName") String firstName, @Param("userSurname") String surName,@Param("pinCode") String pinCode);
    
}
