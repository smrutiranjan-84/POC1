package com.neosoft.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neosoft.controller.UserNotFoundException;
import com.neosoft.model.User;
import com.neosoft.repository.UserRepository;

//defining the business logic
@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public List<User> getAllUsers() {
		List<User> users = new ArrayList<User>();
		userRepository.findAll().forEach(user1 -> users.add(user1));
		return users;
	}
	public List<User> searchUser(String userFirstName,String userSurname,String pinCode)
	{
		List<User> user=userRepository.findByUserFirstNameOrSurNameOrPinCode(userFirstName, userSurname,pinCode);
		return user;
	}

	public User getUserById(int id) {
		return userRepository.findById(id).orElseThrow(
				UserNotFoundException::new);
	}

	public void saveOrUpdate(User users) {
		userRepository.save(users);
	}

	public void delete(int id) {
		userRepository.deleteById(id);
	}

	public void update(User users, int userId) {
		userRepository.save(users);
	}
}